package com.example.inventorysystem

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.inventorysystem.databinding.ActivityAddBinding
import kotlin.Exception


class AddActivity  : AppCompatActivity(), Inventory {
    private lateinit var binding: ActivityAddBinding
    private lateinit var dh: DataHelper
    private lateinit var data: Data

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.cancelBtn.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
        binding.saveBtn.setOnClickListener {

            try {

                val number: String = binding.itemNumberInput.getText().toString()
                val product: String = binding.productnameInput.getText().toString()
                val cost: String = binding.itemCostInput.getText().toString()
                val price: String = binding.productPrice.getText().toString()
                val qty: String = binding.qtyText.getText().toString()

                   val itemNumber: Int = java.lang.Integer.parseInt(number)
                   val item_cost: Double = java.lang.Double.parseDouble(cost)
                   val item_price: Double = java.lang.Double.parseDouble(price)
                   val item_qty: Int = java.lang.Integer.parseInt(qty)

               if(addCheck(itemNumber)) {
                   var i: Int = 0
                   Toast.makeText(this, "Item added", Toast.LENGTH_LONG).show()
                   while(i < item_qty) {

                       inventoryItem(itemNumber, product, item_cost, item_price)
                       startActivity(Intent(this, MainActivity::class.java))
                       i++
                   }
               }
                else{   Toast.makeText(this,"Item number $itemNumber already exists", Toast.LENGTH_LONG)
                   .show()
                   binding.itemNumberInput.setText("")


                   }
            } catch (e: Exception) {
                Toast.makeText(this, "Invalid Entry. Please try again", Toast.LENGTH_LONG).show()
                e.printStackTrace()

            }
        }
    }

    fun addCheck(number: Int) : Boolean {
        dh = DataHelper(this)
        var b: Boolean = true

        if(dh.searchItem(number) != -1){
            b = false
        }
        return b
    }

    override fun inventoryItem(number: Int, product: String, cost: Double, price: Double)  {

        try {
            data = Data(0, number, product, cost, price)
            dh = DataHelper(this)
            dh.insertItem(data)

        }
        catch (e: Exception){
            Toast.makeText(this, "Unable to add item", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }

        startActivity(Intent(this, MainActivity::class.java))

    }


}