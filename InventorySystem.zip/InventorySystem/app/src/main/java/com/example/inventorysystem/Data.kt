package com.example.inventorysystem

data class Data(val id: Int, val itemNumber: Int, val product: String, val cost: Double, val price: Double)
