package com.example.inventorysystem


import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper




class DataHelper(context: Context)  : SQLiteOpenHelper(context, DATABASE_NAME, null, VERSION) {
    private lateinit var dh: DataHelper



    companion object {
        private const val DATABASE_NAME = "inventory_data"
        private const val VERSION = 1
        private const val TABLE_NAME = "inventory_list"
        private const val COLUMN_ID = "id"
        private const val COLUMN_NUMBER = "item_number"
        private const val COLUMN_PRODUCT = "product"
        private const val COLUMN_COST = "price"
        private const val COLUMN_PRICE = "cost"
    }


    override fun onCreate(db: SQLiteDatabase?) {
        val query =
            "CREATE TABLE $TABLE_NAME($COLUMN_ID INTEGER PRIMARY KEY, $COLUMN_NUMBER INTEGER, " +
                    "$COLUMN_PRODUCT TEXT, $COLUMN_COST DOUBLE, $COLUMN_PRICE DOUBLE)"
        db?.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val dropTable = "DROP TABLE IF EXISTS $TABLE_NAME"
        onCreate(db)
    }

    fun insertItem(data: Data) {
        val db = writableDatabase
        val value = ContentValues().apply {
            put(COLUMN_NUMBER, data.itemNumber)
            put(COLUMN_PRODUCT, data.product)
            put(COLUMN_COST, data.cost)
            put(COLUMN_PRICE, data.price)
        }
        db.insert(TABLE_NAME, null, value)
        db.close()
    }

    fun countofAmoumnt() : Double {

        val inventory = mutableListOf<Data>()
        val db = readableDatabase
        val query = "SELECT * FROM $TABLE_NAME"
        val cursor = db.rawQuery(query, null)
        var costOfItems: Double = 0.0

        while (cursor.moveToNext()) {
            val id = cursor.getInt((cursor.getColumnIndexOrThrow(COLUMN_ID)))
            val item_number = cursor.getInt((cursor.getColumnIndexOrThrow(COLUMN_NUMBER)))
            val product = cursor.getString((cursor.getColumnIndexOrThrow(COLUMN_PRODUCT)))
            val cost = cursor.getDouble((cursor.getColumnIndexOrThrow(COLUMN_COST)))
            val price = cursor.getDouble((cursor.getColumnIndexOrThrow(COLUMN_PRICE)))

            costOfItems = costOfItems + cost

        }
        return costOfItems
    }


    fun searchItem(itemNumber: Int) : Int {
        val db = readableDatabase
        val query = "SELECT * FROM $TABLE_NAME WHERE $COLUMN_NUMBER LIKE '%$itemNumber%'"
        val cursor = db.rawQuery(query, null)

        while(cursor.moveToNext())   {
            val id = cursor.getInt((cursor.getColumnIndexOrThrow(COLUMN_ID)))
            val item_number = cursor.getInt((cursor.getColumnIndexOrThrow(COLUMN_NUMBER)))

            if(item_number == itemNumber){

                return id
            }
        }
        db.close()
        cursor.close()
        return  -1

    }

    fun getAllInventoryItems(): List<Data> {
        val inventory = mutableListOf<Data>()
        val db = readableDatabase
        val query = "SELECT * FROM $TABLE_NAME"
        val cursor = db.rawQuery(query, null)

        while (cursor.moveToNext()) {
            val id = cursor.getInt((cursor.getColumnIndexOrThrow(COLUMN_ID)))
            val item_number = cursor.getInt((cursor.getColumnIndexOrThrow(COLUMN_NUMBER)))
            val product = cursor.getString((cursor.getColumnIndexOrThrow(COLUMN_PRODUCT)))
            val cost = cursor.getDouble((cursor.getColumnIndexOrThrow(COLUMN_COST)))
            val price = cursor.getDouble((cursor.getColumnIndexOrThrow(COLUMN_PRICE)))

            val data = Data(id, item_number, product, cost, price)
            inventory.add(data)
        }

        cursor.close()

        return inventory

    }

    fun getItemByID(taskId: Int): Data {
        val db = readableDatabase
        val query = "SELECT * FROM $TABLE_NAME WHERE $COLUMN_ID - $taskId"
        val cursor = db.rawQuery(query, null)
        cursor.moveToFirst()

        val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))
        val number = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_NUMBER))
        val product = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRODUCT))
        val cost = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_COST))
        val price = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_PRICE))

        cursor.close()
        db.close()
        val data = Data(id, number, product, cost, price)
        return (data)
    }

    fun deleteItem(taskId: Int) {
        val db = writableDatabase
        val whereClausz = "$COLUMN_ID = ?"
        val whereArgs = arrayOf(taskId.toString())
        db.delete(TABLE_NAME, whereClausz, whereArgs)
        db.close()
    }


}


