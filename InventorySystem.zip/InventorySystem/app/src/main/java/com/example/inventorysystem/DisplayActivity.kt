package com.example.inventorysystem

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.inventorysystem.databinding.ActivityDisplayBinding

class DisplayActivity : AppCompatActivity() {
    private lateinit var db: DataHelper

    private lateinit var binding: ActivityDisplayBinding



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityDisplayBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_display)

        db = DataHelper(this)

        val listAdapter: ListAdapter = ListAdapter(db.getAllInventoryItems(), this)
        var ints = listAdapter.itemCount
        var i = 0

        while(ints != 0){

          val data: Data =  db.getItemByID(i)

       }

    }




    }





