package com.example.inventorysystem

interface Inventory {

    fun inventoryItem(number: Int, product: String, cost: Double, price: Double)
}