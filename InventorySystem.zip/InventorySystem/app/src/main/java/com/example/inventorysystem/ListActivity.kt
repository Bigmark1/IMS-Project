package com.example.inventorysystem

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.inventorysystem.databinding.ActivityListBinding



class ListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListBinding
    private lateinit var db: DataHelper
    private lateinit var listAdapter: ListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = DataHelper(this)
        listAdapter = ListAdapter(db.getAllInventoryItems(), this)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = listAdapter
        binding.listBackBtn.setOnClickListener{
            startActivity(Intent(this, MainActivity::class.java))

        }

    }

    override fun onResume() {
        super.onResume()
        listAdapter.refreshData(db.getAllInventoryItems())
    }
}











