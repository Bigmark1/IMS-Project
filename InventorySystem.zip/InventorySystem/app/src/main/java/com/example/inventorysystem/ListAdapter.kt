package com.example.inventorysystem

import android.content.Context
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import org.w3c.dom.Text


class ListAdapter(private var data: List<Data>, context: Context) : RecyclerView.Adapter<ListAdapter.InventoryViewHolder>() {
    private val db: DataHelper = DataHelper(context)


    class InventoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){

        val itemViewText: TextView = itemView.findViewById(R.id.display_product)
        val priceViewText: TextView = itemView.findViewById(R.id.display_price)
        val numberViewText: TextView = itemView.findViewById(R.id.display_number)
        val deleteButton: ImageView = itemView.findViewById(R.id.deleteBtn)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) : InventoryViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_display, parent,false)
        return InventoryViewHolder(view)
    }

   override  fun getItemCount(): Int = data.size

   override  fun onBindViewHolder(holder: InventoryViewHolder, position: Int){

        val data = data[position]
        holder.itemViewText.text =data.product
        holder.priceViewText.text ="$" + data.price.toString()
       holder.numberViewText.text ="#" + data.itemNumber.toString()

       holder.deleteButton.setOnClickListener{

           alertPop(holder.itemView.context, data.id)
           Toast.makeText(holder.itemView.context, "Deleted item", Toast.LENGTH_LONG).show()
       }

   }
    fun alertPop (context: Context, dataId: Int)  {

     val builder : AlertDialog.Builder = AlertDialog.Builder(context)
        builder
            .setMessage("Delete this item?")
            .setTitle("Delete Item")
            .setNegativeButton("Yes") { dialog, which ->
                db.deleteItem(dataId)
                refreshData(db.getAllInventoryItems())

            }
            .setPositiveButton("No"){ dialog, which ->

            }
        val dialog: AlertDialog = builder.create()
        dialog.show()

    }

    fun refreshData(newTask: List<Data>) {
        data = newTask
        notifyDataSetChanged()
    }

}









