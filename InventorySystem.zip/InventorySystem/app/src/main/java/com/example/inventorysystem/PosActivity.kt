package com.example.inventorysystem

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.inventorysystem.databinding.ActivityPosBinding


class PosActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPosBinding
    private lateinit var db: DataHelper
    private lateinit var arrayList: List<Data>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       binding = ActivityPosBinding.inflate(layoutInflater)
        db = DataHelper(this)
        setContentView(binding.root)
        val backButton = findViewById<Button>(R.id.button)

        backButton.setOnClickListener{
            startActivity(Intent(this, MainActivity::class.java))
        }

        arrayList = db.getAllInventoryItems()
        fun getCount(): Int = arrayList.size
        val count: Int = getCount()
        binding.numUnitAmount.setText(count.toString() + " Units")
        val costOf: Double = db.countofAmoumnt()


        binding.costAmount.setText("$"+costOf.toString())

         val format =  java.text.DecimalFormat("##.##")
         val average: Double = costOf/count

            binding.averageAmount.setText("$"+ format.format(average).toString())



    }

}

